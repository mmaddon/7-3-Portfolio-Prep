package com.example.myapplication;



import androidx.appcompat.app.AppCompatActivity;


import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText username, password, repassword;
    Button signup, signin;
    WeightDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_main);

          username =(EditText)findViewById(R.id.username);
          password =(EditText)findViewById(R.id.password);
          repassword =(EditText)findViewById(R.id.repassword);
          signup =(Button)findViewById(R.id.btn_signin);
          dbHelper = new WeightDBHelper(getApplicationContext());
          SQLiteDatabase db = dbHelper.getWritableDatabase();
          signup.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  // Check if the user already exists
                  // If not check if the passwords match
                  // If passwords match insert user in the database
                  // Create a new map of values, creates user name and password
                  ContentValues values = new ContentValues();
                  values.put(DBFollower.UserEntry.COLUMN_NAME_USERNAME, "username");
                  values.put(DBFollower.UserEntry.COLUMN_NAME_PASSWORD, "password");

                  // Insert the new row, returning the primary key value of the new row
                  long newRowId = db.insert(DBFollower.UserEntry.TABLE_NAME, null, values);
                  Log.d("main activity", String.valueOf(newRowId));
                  testDB();
                  // If the user already exists, display message
                  // If the passwords don't match, display message
              }
          });



    }
    public void testDB(){
            SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                BaseColumns._ID,
                DBFollower.UserEntry.COLUMN_NAME_USERNAME,
                DBFollower.UserEntry.COLUMN_NAME_PASSWORD,
                DBFollower.UserEntry.COLUMN_NAME_DATE,
                DBFollower.UserEntry.COLUMN_NAME_WEIGHT
        };

        // Filter results WHERE "title" = 'My Title'
        String selection = DBFollower.UserEntry.COLUMN_NAME_USERNAME + " = ?";
        String[] selectionArgs = { "username" };

        // How you want the results sorted in the resulting Cursor
        String sortOrder =
                DBFollower.UserEntry.COLUMN_NAME_DATE + " DESC";
        //Line 74 creates cursor that allows to get the information out of the database and print out.
        Cursor cursor = db.query(
                DBFollower.UserEntry.TABLE_NAME,   // The table to query
                projection,             // The array of columns to return (pass null to get all)
                selection,              // The columns for the WHERE clause
                selectionArgs,          // The values for the WHERE clause
                null,           // don't group the rows
                null,            // don't filter by row groups
                null            // The sort order
        );
        List itemIds = new ArrayList<>();
        while(cursor.moveToNext()) {
            long itemId = cursor.getLong(cursor.getColumnIndexOrThrow(DBFollower.UserEntry.COLUMN_NAME_USERNAME));
            itemIds.add(itemId);
        }
        cursor.close();

        // Check data by printing to the log
        for (int i = 0; i < itemIds.size(); i++)
            Log.d("MainActivity", String.valueOf(itemIds.get(i)));
    }
    public void signInClick(View view){
        Intent intent = new Intent(this,LoginActivity.class);
        startActivity(intent);
    }
}


