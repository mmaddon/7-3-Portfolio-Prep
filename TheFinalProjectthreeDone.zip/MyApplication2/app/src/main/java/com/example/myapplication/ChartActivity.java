package com.example.myapplication;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.internal.TextWatcherAdapter;

public class ChartActivity extends AppCompatActivity {
    private Context context;
    // Register the permissions callback
    private ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    checkWeightGoal();
                    // Permission is granted
                } else {
                    Toast.makeText(getApplicationContext(), ("Congratulations you reached your target weight"), Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        EditText weightOne = findViewById(R.id.weight1);
        EditText weightTwo = findViewById(R.id.weight2);
        EditText weightThree = findViewById(R.id.weight3);

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String text = s.toString();
                if (!text.isEmpty()) {
                    checkWeightGoal();
                }

            }
        };
        weightOne.addTextChangedListener(textWatcher);
        weightTwo.addTextChangedListener(textWatcher);
        weightThree.addTextChangedListener(textWatcher);

        context = getApplicationContext();

    }
    public void checkWeightGoal(){
        double weight = 0;
        double TargetWeight = 180;
        EditText weightOne = findViewById(R.id.weight1);
        EditText weightTwo = findViewById(R.id.weight2);
        EditText weightThree = findViewById(R.id.weight3);
        String text1 = weightOne.getText().toString();
        String text2 = weightTwo.getText().toString();
        String text3 = weightThree.getText().toString();
        weight = Double.parseDouble(text1);
        double weight2 = Double.parseDouble(text2);
        double weight3 = Double.parseDouble(text3);
        weight = Math.min(weight,weight2);
        weight = Math.min(weight, weight3);

        if (weight <= TargetWeight && weight >= 100){
            if (ContextCompat.checkSelfPermission(
                    context, Manifest.permission.SEND_SMS) ==
                    PackageManager.PERMISSION_GRANTED) {
                // user can use the specific API that requires the permission.

                // if permission is granted, toast will show.
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("45241541", null, "Congratulations you reached your target weight", null, null);
            } else if (shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)){
                // continues using your app without granting the permission.
                Toast.makeText(getApplicationContext(), ("Congratulations you reached your target weight"), Toast.LENGTH_LONG).show();

            } else {
                // user directly asks for the permission
                requestPermissionLauncher.launch(
                        Manifest.permission.SEND_SMS);
            }
        }

    }
}