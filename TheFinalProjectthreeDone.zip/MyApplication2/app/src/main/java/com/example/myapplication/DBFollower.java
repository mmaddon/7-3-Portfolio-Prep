package com.example.myapplication;


import android.provider.BaseColumns;

public final class DBFollower {


        private DBFollower() {}

        //defines the table contents */
        public static class UserEntry implements BaseColumns {
            public static final String TABLE_NAME = "users";
            public static final String COLUMN_NAME_USERNAME = "username";
            public static final String COLUMN_NAME_PASSWORD = "password";
            public static final String COLUMN_NAME_DATE = "date";
            public static final String COLUMN_NAME_WEIGHT = "weight";
        }
    }



